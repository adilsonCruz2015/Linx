﻿

using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using Linx.Domain.Interfaces.Repositories;
using Linx.Infra.Data.Context;

namespace Linx.Infra.Data.Repositories
{
    public class RepositoryBase<TEntity> : IDisposable, IRepositoryBase<TEntity> where TEntity : class
    {
        protected LinxContext Db = new LinxContext();

        protected DbSet<TEntity> Entity { get { return Db.Set<TEntity>(); } }


        public void Add(TEntity obj)
        {
            Entity.Add(obj);
            Commit();
        }

        public TEntity GetById(int id)
        {
            return Entity.Find(id);
        }

        public IEnumerable<TEntity> GetAll()
        {
            return Entity.ToList();
        }

        public void Update(TEntity obj)
        {
            Db.Entry(obj).State = EntityState.Modified;
            Commit();
        }

        public void Remove(TEntity obj)
        {
            Entity.Remove(obj);
            Commit();
        }

        public void Dispose()
        {
            Db.Dispose();
        }

        public void Commit()
        {
            Db.SaveChanges();
        }
    }
}
