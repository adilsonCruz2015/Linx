﻿

using Linx.Domain.Entities;
using Linx.Domain.Interfaces.Repositories;

namespace Linx.Infra.Data.Repositories
{
    public class UserRepository : RepositoryBase<User>, IUserRepository
    {
    }
}
