﻿
using Linx.Domain.Entities;
using Linx.Domain.Interfaces.Repositories;

namespace Linx.Infra.Data.Repositories
{
    public class ProdutoRepository : RepositoryBase<Product>, IProductRepository
    {
    }
}
