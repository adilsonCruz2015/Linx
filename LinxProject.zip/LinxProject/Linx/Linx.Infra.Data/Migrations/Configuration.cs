

namespace Linx.Infra.Data.Migrations
{

    using System.Data.Entity.Migrations;
    using Linx.Infra.Data.Seeds;

    internal sealed class Configuration : DbMigrationsConfiguration<Linx.Infra.Data.Context.LinxContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(Linx.Infra.Data.Context.LinxContext context)
        {
            UserSeed.Sedd(context);
            ProductSeed.Sedd(context);

        }
    }
}
