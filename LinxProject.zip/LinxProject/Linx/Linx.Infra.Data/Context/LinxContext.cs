﻿

using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using Linx.Domain.Entities;
using Linx.Infra.Data.EntityConfig;

namespace Linx.Infra.Data.Context
{
    public class LinxContext : DbContext
    {
        public LinxContext():base("name=linxConnection"){}


        public DbSet<User> Users { get; set; }
        public DbSet<Product> Products { get; set; }


        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
            modelBuilder.Conventions.Remove<OneToManyCascadeDeleteConvention>();
            modelBuilder.Conventions.Remove<ManyToManyCascadeDeleteConvention>();

            modelBuilder.Properties()
                .Where(p => p.ReflectedType != null && p.Name == p.ReflectedType.Name + "Id")
                .Configure(p => p.IsKey());

            modelBuilder.Properties<string>()
                .Configure(p => p.HasColumnType("varchar"));

            modelBuilder.Properties<string>()
                .Configure(p => p.HasMaxLength(100));

            ConfigureEntities(modelBuilder);
        }


        private void ConfigureEntities(DbModelBuilder modelBuilder)
        {
            modelBuilder.Configurations.Add(new UserConfiguration());
            modelBuilder.Configurations.Add(new ProductConfiguration());
        }
    }
}
