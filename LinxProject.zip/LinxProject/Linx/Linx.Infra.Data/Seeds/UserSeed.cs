﻿

using System.Collections.Generic;
using System.Data.Entity.Migrations;
using Linx.Domain.Entities;

namespace Linx.Infra.Data.Seeds
{
    public class UserSeed
    {
        public static void Sedd(Linx.Infra.Data.Context.LinxContext context)
        {
            var users = new List<User>
            {
                new User {Login = "adilsoncruz", Password = "123456"},
                new User {Login = "renata", Password = "1234"}
            };


            foreach (var user in users)
            {
                context.Users.AddOrUpdate(user);
            }
        }
    }
}
