﻿

using System.Collections.Generic;
using System.Data.Entity.Migrations;
using Linx.Domain.Entities;

namespace Linx.Infra.Data.Seeds
{
    public class ProductSeed
    {
        public static void Sedd(Linx.Infra.Data.Context.LinxContext context)
        {
            var products = new List<Product>
            {
                new Product {Name = "Tenis", Price = 120},
                new Product {Name = "Camisa", Price = 85},
                new Product {Name = "Meia", Price = 25},
                new Product {Name = "Chinelo", Price = 15},
                new Product {Name = "Bola", Price = 35}
            };


            foreach (var product in products)
            {
                context.Products.AddOrUpdate(product);
            }
        }
    }
}
