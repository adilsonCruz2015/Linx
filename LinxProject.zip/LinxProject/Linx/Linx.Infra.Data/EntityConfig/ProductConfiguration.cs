﻿

using System.Data.Entity.ModelConfiguration;
using Linx.Domain.Entities;

namespace Linx.Infra.Data.EntityConfig
{
    public class ProductConfiguration :EntityTypeConfiguration<Product>
    {
        public ProductConfiguration()
        {
            ToTable("Product");

            HasKey(p => p.ProductId);

            Property(p => p.Name)
                .IsRequired()
                .HasMaxLength(Product.NameMaxlenght);

            Property(p => p.Price)
                .IsRequired();
        }
    }
}
