﻿

using System.Data.Entity.ModelConfiguration;
using Linx.Domain.Entities;

namespace Linx.Infra.Data.EntityConfig
{
    public class UserConfiguration : EntityTypeConfiguration<User>
    {
        public UserConfiguration()
        {
            ToTable("User");

            HasKey(u => u.UserId);

            Property(u => u.Login)
                .IsRequired()
                .HasMaxLength(User.LoginMaxLength);

            Property(u => u.Password)
                .IsRequired()
                .HasMaxLength(User.PasswordMaxLength);
        }
    }
}
