﻿

using Linx.Domain.Entities;

namespace Linx.Application.Interface
{
    public interface IProductAppService : IAppServiceBase<Product>
    {
    }
}
