﻿

using Linx.Domain.Entities;

namespace Linx.Application.Interface
{
    public interface IUserAppService : IAppServiceBase<User>
    {
        bool Authenticate(User user);
    }
}
