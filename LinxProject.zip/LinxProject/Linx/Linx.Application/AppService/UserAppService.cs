﻿

using Linx.Application.Interface;
using Linx.Domain.Entities;
using Linx.Domain.Interfaces.Services;

namespace Linx.Application.AppService
{
    public class UserAppService : AppServiceBase<User>, IUserAppService
    {
        private readonly IUserService _userService;

        public UserAppService(IUserService userService):base(userService)
        {
            _userService = userService;
        }

        public bool Authenticate(User user)
        {
            return _userService.Authenticate(user);
        }
    }
}
