﻿

using Linx.Application.Interface;
using Linx.Domain.Entities;
using Linx.Domain.Interfaces.Services;

namespace Linx.Application.AppService
{
    public class ProductAppService : AppServiceBase<Product>, IProductAppService
    {
        private readonly IProductService _productAppService;

        public ProductAppService(IProductService productAppService)
            : base(productAppService)
        {
            _productAppService = productAppService;
        }
    }
}
