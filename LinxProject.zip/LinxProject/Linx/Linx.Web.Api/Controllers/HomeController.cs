﻿

using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Web.Mvc;
using System.Web.Security;
using Linx.Web.Api.ViewModel;
using RestSharp;

namespace Linx.Web.Api.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(string userName, string password)
        {
            var client = new RestClient("http://localhost:51274/");

            var request = new RestRequest("/security/token", Method.POST);
            request.AddParameter("grant_type", "password");
            request.AddParameter("username", userName);
            request.AddParameter("password", password);

            var response = client.Execute<TokenViewModel>(request);
            var token = response.Data.access_token;

            if (!string.IsNullOrEmpty(token))
                FormsAuthentication.SetAuthCookie(token, false);

            return RedirectToAction("Menu");
        }

        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Index");
        }

        [Authorize]
        public ActionResult Menu()
        {
            ViewBag.Nome = User.Identity.Name;
            return View();
        }

        public  ActionResult ListProduct()
        {
            //var client = new RestClient("http://localhost:51274");
            //var request = new RestRequest("/api/product/", Method.GET);
            //var response = client.Execute<ProductViewModel>(request);

            var client = new HttpClient();
            Uri usuarioUri;
            client.BaseAddress = new Uri("http://localhost:51274");
            client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

            var response = client.GetAsync("api/product").Result;

            IEnumerable<ProductViewModel> productViewModels;

            if (response.IsSuccessStatusCode)
            {
                productViewModels = response.Content.ReadAsAsync<IEnumerable<ProductViewModel>>().Result;
            }
            else
            {
                Response.Write(response.StatusCode.ToString() + " - " + response.ReasonPhrase);
            }



            return View("ListProduct");
        }

    }
}
