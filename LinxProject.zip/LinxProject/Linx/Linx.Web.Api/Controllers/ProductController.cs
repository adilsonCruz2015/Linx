﻿
using System.Collections.Generic;
using System.Web.Http;
using Linx.Application.Interface;
using Linx.Domain.Entities;


namespace Linx.Web.Api.Controllers
{
    public class ProductController : ApiController
    {

        private readonly IProductAppService _productAppService;

        public ProductController(IProductAppService productAppService)
        {
            _productAppService = productAppService;
        }

        // GET: api/Product
        public IEnumerable<Product> Get()
        {
            var products = _productAppService.GetAll();
            return products;
        }

        // GET: api/Product/5
        public string Get(int id)
        {
            return "value";
        }

        // POST: api/Product
        public void Post([FromBody]string value)
        {
        }

        // PUT: api/Product/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/Product/5
        public void Delete(int id)
        {
        }
    }
}
