﻿

using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Linx.Web.Api.ViewModel
{
    public class ProductViewModel
    {
        [Key]
        [DisplayName("Código do Produto")]
        public int ProductId { get; set; }

        [DisplayName("Nome do Produto")]
        public string Name { get; set; }

        [DisplayName("Preço do Produto")]
        [Range(typeof(decimal), "0", "999999999999")]
        public decimal Price { get; set; }
    }
}