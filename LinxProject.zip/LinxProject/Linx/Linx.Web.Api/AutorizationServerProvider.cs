﻿

using System.Collections.Generic;
using System.Security.Claims;
using System.Security.Principal;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Http;
using Linx.Application.AppService;
using Linx.Application.Interface;
using Linx.Domain.Entities;
using Microsoft.Owin.Security.OAuth;


namespace Linx.Web.Api
{
    public class AutorizationServerProvider : OAuthAuthorizationServerProvider
    {

        //private readonly IUserAppService _userAppService;


        //public AutorizationServerProvider(IUserAppService userAppService)
        //{
        //    _userAppService = userAppService;
        //}

        public override async Task ValidateClientAuthentication(OAuthValidateClientAuthenticationContext context)
        {
            context.Validated();
        }

        public override async Task GrantResourceOwnerCredentials(OAuthGrantResourceOwnerCredentialsContext context)
        {
            context.OwinContext.Response.Headers.Add("Access-Control-Allow-Origin", new[] {"*"});

            try
            {

                var user = context.UserName;

                var userFind = new User {Login = context.UserName, Password = context.Password};


                //var result = _userAppService.Authenticate(userFind);
                var result = true;

                if (!result)
                {
                    context.SetError("invalid_grant", "Usuário ou senha inválidos");
                    return;
                }

                var identity = new ClaimsIdentity(context.Options.AuthenticationType);

                identity.AddClaim(new Claim(ClaimTypes.Name, user));

                var roles = new List<string>();

                roles.Add("User");
                roles.Add("Admin");

                foreach (var role in roles)
                {
                    identity.AddClaim(new Claim(ClaimTypes.Role, role));
                }

                var principal = new GenericPrincipal(identity, roles.ToArray());
                Thread.CurrentPrincipal = principal;

                context.Validated(identity);

            }
            catch
            {
                context.SetError("invalid_grant", "Falha ao autenticar");
            }
        }
    }
}