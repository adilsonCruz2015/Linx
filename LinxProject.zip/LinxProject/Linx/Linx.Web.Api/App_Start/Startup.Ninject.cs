﻿
using System.Reflection;
using System.Web.Http;
using System.Web.Mvc;
using Linx.Application.AppService;
using Linx.Application.Interface;
using Linx.Domain.Interfaces.Repositories;
using Linx.Domain.Interfaces.Services;
using Linx.Domain.Services;
using Linx.Infra.Data.Repositories;

using Ninject;
using Ninject.Modules;
using Ninject.Web.Common.OwinHost;
using Ninject.Web.WebApi.OwinHost;
using Owin;



namespace Linx.Web.Api
{
    public partial class Startup
    {
        public IKernel ConfigureNinject(IAppBuilder app)
        {
              var config = new HttpConfiguration(); 
              var kernel = CreateKernel(); 
              app.UseNinjectMiddleware(() => kernel).UseNinjectWebApi(config); 
              return kernel;
        }

        public IKernel CreateKernel()
        {
             var kernel = new StandardKernel(); 
             kernel.Load(Assembly.GetExecutingAssembly()); 
             return kernel;
        }
    }

    public class NinjectConfig : NinjectModule
    {
        public override void Load()
        {
            RegisterServices();
            
        }

        private void RegisterServices()
        {

            Kernel.Bind(typeof(IAppServiceBase<>)).To(typeof(AppServiceBase<>));
            Kernel.Bind<IUserAppService>().To<UserAppService>();


            Kernel.Bind(typeof(IServiceBase<>)).To(typeof(ServiceBase<>));
            Kernel.Bind<IUserService>().To<UserService>();

            Kernel.Bind(typeof(IRepositoryBase<>)).To(typeof(RepositoryBase<>));
            Kernel.Bind<IUserRepository>().To<UserRepository>();
        }
    }
}