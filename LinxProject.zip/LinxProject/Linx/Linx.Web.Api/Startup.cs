﻿

using System;
using System.Reflection;
using System.Web.Http;
using System.Web.Mvc;
using Linx.Web.Api.Ninject;
using Microsoft.Owin;
using Microsoft.Owin.Security.OAuth;
using Ninject;
using Owin;

namespace Linx.Web.Api
{
    public  class Startup
    {

        public void Configuration(IAppBuilder app)
        {
            var config = new HttpConfiguration();
            //var kernel = ConfigureNinject(app);
            //var kernel = new NinjectLinx();

            WebApiConfig.Register(config);
            

            //app.UseNinjectMiddleware(CreateKernel);
            //app.UseNinjectWebApi(config);


            //ConfigureOAuth(app, kernel);
            ConfigureOAuth(app);

            app.UseCors(Microsoft.Owin.Cors.CorsOptions.AllowAll);
            app.UseWebApi(config);
        }
        

        //public void ConfigureOAuth(IAppBuilder app, IKernel kernel)
        public void ConfigureOAuth(IAppBuilder app)
        {
            OAuthAuthorizationServerOptions OAuthServerOptions = new OAuthAuthorizationServerOptions()
            {
                AllowInsecureHttp = true,
                TokenEndpointPath = new PathString("/security/token"),
                AccessTokenExpireTimeSpan = TimeSpan.FromMinutes(1),
               // Provider = new AutorizationServerProvider(kernel.Get<UserAppService>())
                //Provider = new AutorizationServerProvider(kernel.Get<UserAppService>())
                Provider = new AutorizationServerProvider()
            };

            app.UseOAuthAuthorizationServer(OAuthServerOptions);
            app.UseOAuthBearerAuthentication(new OAuthBearerAuthenticationOptions());
        }

        private static StandardKernel CreateKernel()
        {
            var kernel = new StandardKernel();
            kernel.Load(Assembly.GetExecutingAssembly());

            ControllerBuilder.Current.SetControllerFactory(new NinjectLinx(kernel));

            //RegisterServices(kernel); 
            return kernel;
        }
        //private static void RegisterServices(IKernel kernel)
        //{
        //    var containerConfigurator = new NinjectConfigurator();
        //    containerConfigurator.Configure(kernel);
        //}
    }
}