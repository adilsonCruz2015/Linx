﻿

using System;
using System.Drawing.Text;
using System.Reflection;
using System.Web.Mvc;
using System.Web.Routing;
using Linx.Application.AppService;
using Linx.Application.Interface;
using Linx.Domain.Interfaces.Repositories;
using Linx.Domain.Interfaces.Services;
using Linx.Domain.Services;
using Linx.Infra.Data.Repositories;
using Ninject;

namespace Linx.Web.Api.Ninject
{
    public class NinjectLinx : DefaultControllerFactory
    {

        public IKernel Kernel { get; private set; }

        public NinjectLinx(IKernel kernel)
        {
            Kernel = kernel;
            Binding();
        }

        
        private void Binding()
        {
            Kernel.Bind(typeof(IAppServiceBase<>)).To(typeof(AppServiceBase<>));
            Kernel.Bind<IUserAppService>().To<UserAppService>();
            Kernel.Bind<IProductAppService>().To<ProductAppService>();


            Kernel.Bind(typeof(IServiceBase<>)).To(typeof(ServiceBase<>));
            Kernel.Bind<IUserService>().To<UserService>();
            Kernel.Bind<IProductService>().To<ProductService>();

            Kernel.Bind(typeof(IRepositoryBase<>)).To(typeof(RepositoryBase<>));
            Kernel.Bind<IUserRepository>().To<UserRepository>();
            Kernel.Bind<IProductRepository>().To<ProdutoRepository>();
        }

        protected override IController GetControllerInstance(RequestContext requestContext, Type controllerType)
        {
            return controllerType == null ? null : (IController)Kernel.Get(controllerType);
        }

    }
}