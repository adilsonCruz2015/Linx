﻿
using Linx.Domain.Entities;
using Linx.Domain.Interfaces.Repositories;
using Linx.Domain.Interfaces.Services;

namespace Linx.Domain.Services
{
    public class ProductService :ServiceBase<Product>, IProductService
    {
        private readonly IProductRepository _productRepository;

        public ProductService(IProductRepository productRepository):base(productRepository)
        {
            _productRepository = productRepository;
        }
    }
}
