﻿

using System.Linq;
using Linx.Domain.Entities;
using Linx.Domain.Interfaces.Repositories;
using Linx.Domain.Interfaces.Services;

namespace Linx.Domain.Services
{
    public class UserService : ServiceBase<User>, IUserService
    {
        private readonly IUserRepository _userRepository;

        public UserService(IUserRepository userRepository):base(userRepository)
        {
            _userRepository = userRepository;
        }


        public User Logar(User user)
        {
            return
                _userRepository
                    .GetAll()
                    .FirstOrDefault(x => x.Login.Equals(user.Login) && x.Password.Equals(user.Password));
        }


        public bool Authenticate(User user)
        {

            var userResult = _userRepository
                    .GetAll()
                    .FirstOrDefault(x => x.Login.Equals(user.Login) && x.Password.Equals(user.Password));

            return userResult != null && userResult.UserId != 0;
        }
    }
}
