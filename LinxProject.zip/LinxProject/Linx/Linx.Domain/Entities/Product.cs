﻿

namespace Linx.Domain.Entities
{
    public class Product
    {
        public int ProductId { get; set; }
        public const int NameMaxlenght = 150;
        public string Name { get; set; }
        public decimal Price { get; set; }
    }
}
