﻿

namespace Linx.Domain.Entities
{
    public class User
    {
        public int UserId { get; set; }

        public const int PasswordMaxLength = 20;
        public string Password { get; set; }

        public const int LoginMaxLength = 255;
        public string Login { get; set; }
    }
}
