﻿

using Linx.Domain.Entities;

namespace Linx.Domain.Interfaces.Services
{
    public interface IProductService : IServiceBase<Product>
    {
    }
}
