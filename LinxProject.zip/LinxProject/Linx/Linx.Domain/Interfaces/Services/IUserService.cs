﻿

using Linx.Domain.Entities;

namespace Linx.Domain.Interfaces.Services
{
    public interface IUserService : IServiceBase<User>
    {
        bool Authenticate(User user);
    }
}
