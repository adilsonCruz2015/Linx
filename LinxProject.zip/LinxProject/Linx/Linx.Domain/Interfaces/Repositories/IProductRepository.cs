﻿

using Linx.Domain.Entities;

namespace Linx.Domain.Interfaces.Repositories
{
    public interface IProductRepository: IRepositoryBase<Product>
    {
    }
}
