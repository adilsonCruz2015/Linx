﻿

using Linx.Domain.Entities;

namespace Linx.Domain.Interfaces.Repositories
{
    public interface IUserRepository : IRepositoryBase<User>
    {
    }
}
