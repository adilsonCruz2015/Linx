﻿
using System.Collections.Generic;
using System.Web.Http;
using Linx.Application.Interface;
using Linx.Domain.Entities;

namespace Linx.Web.Controllers
{
    public class ProductController : ApiController
    {
        private readonly IProductAppService _productAppService;
        private readonly IUserAppService _userAppService;

        public ProductController(IProductAppService productAppService, IUserAppService userAppService)
        {
            _productAppService = productAppService;
            _userAppService = userAppService;
        }

        // GET: api/Product
       
        public IEnumerable<Product> Get()
        {
           var products = _productAppService.GetAll();
           return products;
        }
    }
}
