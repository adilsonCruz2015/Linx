﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using Linx.Web.ViewModel;
using RestSharp;

namespace Linx.Web.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.Title = "Home Page";

            return View();
        }

        [HttpPost]
        public ActionResult Index(string userName, string password)
        {
            var client = new RestClient("http://localhost:50861");

            var request = new RestRequest("/security/token", Method.POST);
            request.AddParameter("grant_type", "password");
            request.AddParameter("username", userName);
            request.AddParameter("password", password);

            var response = client.Execute<TokenViewModel>(request);
            var token = response.Data.access_token;

            if (!string.IsNullOrEmpty(token))
                FormsAuthentication.SetAuthCookie(token, false);

            return RedirectToAction("Menu");
        }

        [Authorize]
        public ActionResult Menu()
        {
            ViewBag.Nome = User.Identity.Name;
            return View();
        }

        public ActionResult ListProduct()
        {

            if (!User.Identity.IsAuthenticated)
            {
                return RedirectToAction("Index");
            }

            var client = new HttpClient();
            
            client.BaseAddress = new Uri("http://localhost:50861");
            client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
            var response = client.GetAsync("api/product").Result;

            IEnumerable<ProductViewModel> productViewModels = new List<ProductViewModel>();

            if (response.IsSuccessStatusCode)
            {
                productViewModels = response.Content.ReadAsAsync<IEnumerable<ProductViewModel>>().Result;
            }
            else
            {
                Response.Write(response.StatusCode.ToString() + " - " + response.ReasonPhrase);
            }
            return View(productViewModels);
        }

        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Index");
        }
    }
}
