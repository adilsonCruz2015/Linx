﻿using System;


namespace Linx.Web
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!User.Identity.IsAuthenticated)

                Response.Redirect("http://localhost:50861/home/index");
        }
    }
}