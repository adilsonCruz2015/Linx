﻿
var app = angular.module('app', ["ngRoute"]);

app.controller('listaController', ['$scope', '$http', function ($scope, $http) {

    
    $scope.listaProduct = function () {
         $http({
             method: 'GET',
             url: '/api/product/'
         }).then(function successCallback(response) {
             alert(response);
             $scope.listaProduct = response;
         }, function errorCallback(response) {
             alert("2");
         });
     }
}]);


var config = function ($routeProvider) {

    $routeProvider
    .when("/api/product/",
           { templateUrl: "/Views/Home/ListProduct.cshtml", controller: "listaController" })

    .otherwise(
           { redirecTo: "/" });
};
app.config(config);

//angular.module('app', ["ngRoute"]);
//config(function ($routProvider){
//    $routProvider.
//    when("/api/product/",
//           { templateUrl: "/Views/Home/ListProduct.cshtml", controller: "listaController" })

//    .otherwise(
//           { redirecTo: "/" });
//});



//controller('listaController',['$scope','$http',function($scope, $http) {
    
//    $scope.listaProduct = function() {
        
//        $http({
//            method: 'GET',
//            url: '/api/product/'
//        }).then(function successCallback(response) {
//            $scope.listaProduct = response;
//        }, function errorCallback(response) {
//        });

//    }
//}]);




