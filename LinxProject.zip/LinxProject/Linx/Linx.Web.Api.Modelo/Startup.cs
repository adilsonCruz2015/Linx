﻿
using System.Web.Http;
using Owin;

namespace Linx.Web.Api.Modelo
{
    public class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            var config = new HttpConfiguration();
            WebApiConfig.Register(config);
            app.UseWebApi(config);
        }
    }
}